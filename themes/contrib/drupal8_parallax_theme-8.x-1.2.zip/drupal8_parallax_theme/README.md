<!-- WHERE TO START -->

1. You can copy this folder to your projects theme folder.
2. login to admin and click on appearance menu tab you will see the list of themes.
3. under uninstalled theme you will see the copied theme name like Drupal 8 Parallax Theme.
4. click on Install and set as default link under that theme and clear cache
5. You will see the theme gets applied to frontpage and now your theme name appear under Installed themes as first in listing.
6. click on setting link under that theme to set the Appearance.

Thanks You!
Zymphonies Team,
http://www.zymphonies.com